
export class Config  {
    readonly bdUrl!: string;
   } 
   