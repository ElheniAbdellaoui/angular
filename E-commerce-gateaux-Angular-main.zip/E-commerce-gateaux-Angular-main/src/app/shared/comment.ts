

export class comment {
    comment!:String;
    rating!:number;
    date!:string;
    
}
