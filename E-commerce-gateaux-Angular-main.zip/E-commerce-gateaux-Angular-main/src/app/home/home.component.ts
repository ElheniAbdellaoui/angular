import { Component } from '@angular/core';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent {

  // source= "../assets/images/img1.jpg";
  source= "../assets/images/home1.jpg";
  img="alt";
  title="";



  



}
