//pour execution mon projet e-commerce (angular)
=====> Finalement il ne faut pas oublier que pour utiliser une base de données on va lancer deux 
serveurs : le 1er celui de notre application lancé avec la commande ng serve, une fois 
positionné dans l’emplacement adéquat ; le 2ème celui du serveur json lancé avec la 
commande json-server --watch db.json -d 2000, une fois positionné dans le dossier adéquat 
(«json-server »). 



# FirstProjet

This project was generated with [Angular CLI](https://github.com/angular/angular-cli) version 16.2.6.

## Development server

Run `ng serve` for a dev server. Navigate to `http://localhost:4200/`. The application will automatically reload if you change any of the source files.

## Code scaffolding

Run `ng generate component component-name` to generate a new component. You can also use `ng generate directive|pipe|service|class|guard|interface|enum|module`.

## Build

Run `ng build` to build the project. The build artifacts will be stored in the `dist/` directory.

## Running unit tests

Run `ng test` to execute the unit tests via [Karma](https://karma-runner.github.io).

## Running end-to-end tests

Run `ng e2e` to execute the end-to-end tests via a platform of your choice. To use this command, you need to first add a package that implements end-to-end testing capabilities.

## Further help

To get more help on the Angular CLI use `ng help` or go check out the [Angular CLI Overview and Command Reference](https://angular.io/cli) page.

![image](https://github.com/user-attachments/assets/d6db051d-65a7-4b01-af11-6e21b61e762f)

